# EduCoord - Interface Mobile

## Visão Geral
Esta é a interface mobile do sistema de gestão escolar EduCoord, desenvolvida com React Native.

## Scripts Disponíveis

### `npm start`
Inicia o servidor de desenvolvimento.

### `npm run android`
Inicia o aplicativo no emulador Android.

### `npm run ios`
Inicia o aplicativo no emulador iOS.

## Estrutura de Pastas
```
EduCoord-Mobile/
  ├── android/
  ├── ios/
  ├── src/
  │   ├── components/
  │   ├── screens/
  │   ├── App.js
  │   ├── index.js
  ├── package.json
```