import React from 'react';
import { View, Text, Button } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View>
      <Text>Bem-vindo ao EduCoord</Text>
      <Button
        title="Ver Usuários"
        onPress={() => navigation.navigate('Users')}
      />
    </View>
  );
};

export default HomeScreen;