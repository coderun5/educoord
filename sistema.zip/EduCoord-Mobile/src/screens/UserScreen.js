import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, Alert } from 'react-native';
import axios from 'axios';
import config from '../config';

const UserScreen = () => {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [editingUser, setEditingUser] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const response = await axios.get(`${config.apiUrl}/users`);
    setUsers(response.data);
  };

  const handleCreateOrUpdateUser = async () => {
    try {
      if (editingUser) {
        // Update user
        await axios.put(`${config.apiUrl}/users/${editingUser._id}`, { name, email, role });
      } else {
        // Create user
        await axios.post(`${config.apiUrl}/users`, { name, email, password, role });
      }
      fetchUsers();
      setName('');
      setEmail('');
      setPassword('');
      setRole('');
      setEditingUser(null);
    } catch (err) {
      Alert.alert('Erro', 'Não foi possível salvar o usuário. Tente novamente.');
    }
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setName(user.name);
    setEmail(user.email);
    setRole(user.role);
  };

  const handleDeleteUser = async (userId) => {
    try {
      await axios.delete(`${config.apiUrl}/users/${userId}`);
      fetchUsers();
    } catch (err) {
      Alert.alert('Erro', 'Não foi possível excluir o usuário. Tente novamente.');
    }
  };

  return (
    <View>
      <Text>Usuários</Text>
      <TextInput
        placeholder="Nome"
        value={name}
        onChangeText={setName}
        style={{ borderWidth: 1, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
        keyboardType="email-address"
        style={{ borderWidth: 1, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Senha"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={{ borderWidth: 1, marginBottom: 10 }}
        editable={!editingUser}
      />
      <TextInput
        placeholder="Papel"
        value={role}
        onChangeText={setRole}
        style={{ borderWidth: 1, marginBottom: 10 }}
      />
      <Button title={editingUser ? 'Atualizar' : 'Criar'} onPress={handleCreateOrUpdateUser} />
      <FlatList
        data={users}
        keyExtractor={user => user._id}
        renderItem={({ item }) => (
          <View>
            <Text>{item.name} ({item.email}) - {item.role}</Text>
            <Button title="Editar" onPress={() => handleEditUser(item)} />
            <Button title="Excluir" onPress={() => handleDeleteUser(item._id)} />
          </View>
        )}
      />
    </View>
  );
};

export default UserScreen;