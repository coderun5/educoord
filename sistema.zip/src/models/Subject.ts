import { Schema, model } from 'mongoose';

const subjectSchema = new Schema({
  name: { type: String, required: true },
  teacher: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now },
});

export const Subject = model('Subject', subjectSchema);