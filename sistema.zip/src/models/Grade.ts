import { Schema, model } from 'mongoose';

const gradeSchema = new Schema({
  student: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  subject: { type: Schema.Types.ObjectId, ref: 'Subject', required: true },
  score: { type: Number, required: true },
  weight: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now },
});

export const Grade = model('Grade', gradeSchema);