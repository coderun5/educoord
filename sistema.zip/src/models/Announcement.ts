import { Schema, model } from 'mongoose';

const announcementSchema = new Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  recipients: [{ type: Schema.Types.ObjectId, ref: 'User' }],
});

export const Announcement = model('Announcement', announcementSchema);