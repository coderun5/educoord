import { Schema, model } from 'mongoose';

const lessonPlanSchema = new Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  teacher: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now },
  approved: { type: Boolean, default: false },
});

export const LessonPlan = model('LessonPlan', lessonPlanSchema);