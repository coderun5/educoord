import express from 'express';
import http from 'http';
import socketIo from 'socket.io';
import mongoose from 'mongoose';
import userRoutes from './routes/userRoutes';
import subjectRoutes from './routes/subjectRoutes';
import lessonPlanRoutes from './routes/lessonPlanRoutes';
import gradeRoutes from './routes/gradeRoutes';
import messageRoutes from './routes/messageRoutes';
import announcementRoutes from './routes/announcementRoutes';
import backupRoutes from './routes/backupRoutes';
import performanceRoutes from './routes/performanceRoutes';

const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const port = process.env.PORT || 3000;
const mongoUri = 'mongodb://localhost:27017/educoord';

// Middleware
app.use(express.json());

// Routes
app.use(userRoutes);
app.use(subjectRoutes);
app.use(lessonPlanRoutes);
app.use(gradeRoutes);
app.use(messageRoutes);
app.use(announcementRoutes);
app.use(backupRoutes);
app.use(performanceRoutes);

// Connect to MongoDB
mongoose.connect(mongoUri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
  server.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}).catch(error => {
  console.error('MongoDB connection error:', error);
});

// Socket.IO
io.on('connection', (socket) => {
  console.log('New client connected');
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

// Emit notifications
app.post('/notifications', (req, res) => {
  const { message, recipients } = req.body;
  recipients.forEach(recipient => {
    io.to(recipient).emit('notification', message);
  });
  res.status(200).send({ success: true });
});