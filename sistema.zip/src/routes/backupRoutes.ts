import express from 'express';
import { exec } from 'child_process';

const router = express.Router();

// Backup data
router.post('/backup', (req, res) => {
  const dbName = 'educoord';
  const backupPath = `./backup/${dbName}-${Date.now()}.gz`;

  exec(`mongodump --db ${dbName} --archive=${backupPath} --gzip`, (error, stdout, stderr) => {
    if (error) {
      return res.status(500).send({ error: 'Backup failed', details: stderr });
    }
    res.status(200).send({ success: true, path: backupPath });
  });
});

// Restore data
router.post('/restore', (req, res) => {
  const { backupPath } = req.body;

  exec(`mongorestore --db educoord --drop --archive=${backupPath} --gzip`, (error, stdout, stderr) => {
    if (error) {
      return res.status(500).send({ error: 'Restore failed', details: stderr });
    }
    res.status(200).send({ success: true });
  });
});

export default router;