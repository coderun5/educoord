import express from 'express';
import { Grade } from '../models/Grade';

const router = express.Router();

router.get('/performance', async (req, res) => {
  try {
    const performanceData = await Grade.aggregate([
      { $group: { _id: '$student', averageScore: { $avg: '$score' } } },
      { $sort: { averageScore: -1 } }
    ]);
    res.status(200).send(performanceData);
  } catch (error) {
    res.status(500).send(error);
  }
});

router.get('/attendance', async (req, res) => {
  // Implement the logic to fetch attendance data
  const attendanceData = [
    { id: 1, date: '2023-03-01', studentName: 'João Silva', present: true },
    { id: 2, date: '2023-03-01', studentName: 'Maria Oliveira', present: false },
    // Add more records
  ];
  res.status(200).send(attendanceData);
});

export default router;