import express from 'express';
import { Grade } from '../models/Grade';

const router = express.Router();

// Create a new grade
router.post('/grades', async (req, res) => {
  try {
    const grade = new Grade(req.body);
    await grade.save();
    res.status(201).send(grade);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Get all grades
router.get('/grades', async (req, res) => {
  try {
    const grades = await Grade.find({});
    res.send(grades);
  } catch (error) {
    res.status(500).send(error);
  }
});

export default router;