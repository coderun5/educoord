import express from 'express';
import { LessonPlan } from '../models/LessonPlan';

const router = express.Router();

// Create a new lesson plan
router.post('/lessonplans', async (req, res) => {
  try {
    const lessonPlan = new LessonPlan(req.body);
    await lessonPlan.save();
    res.status(201).send(lessonPlan);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Get all lesson plans
router.get('/lessonplans', async (req, res) => {
  try {
    const lessonPlans = await LessonPlan.find({});
    res.send(lessonPlans);
  } catch (error) {
    res.status(500).send(error);
  }
});

export default router;