import express from 'express';
import { Message } from '../models/Message';

const router = express.Router();

// Send a new message
router.post('/messages', async (req, res) => {
  try {
    const message = new Message(req.body);
    await message.save();
    res.status(201).send(message);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Get all messages for a user
router.get('/messages/:userId', async (req, res) => {
  try {
    const messages = await Message.find({ recipient: req.params.userId });
    res.send(messages);
  } catch (error) {
    res.status(500).send(error);
  }
});

export default router;