import express from 'express';
import { Announcement } from '../models/Announcement';

const router = express.Router();

// Create a new announcement
router.post('/announcements', async (req, res) => {
  try {
    const announcement = new Announcement(req.body);
    await announcement.save();
    res.status(201).send(announcement);
  } catch (error) {
    res.status(400).send(error);
  }
});

// Get all announcements
router.get('/announcements', async (req, res) => {
  try {
    const announcements = await Announcement.find({});
    res.send(announcements);
  } catch (error) {
    res.status(500).send(error);
  }
});

export default router;