import React, { useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom';
import HomePage from './pages/HomePage';
import UserPage from './pages/UserPage';
import LoginPage from './pages/LoginPage';
import socketIOClient from 'socket.io-client';
import config from './config';

const PrivateRoute = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render={(props) =>
      localStorage.getItem('token') ? (
        <Component {...props} />
      ) : (
        <Redirect to="/login" />
      )
    }
  />
);

function App() {
  useEffect(() => {
    const socket = socketIOClient(config.apiUrl);
    socket.on('notification', (message) => {
      alert(`Notification: ${message}`);
    });
    return () => socket.disconnect();
  }, []);

  return (
    <Router>
      <Switch>
        <Route path="/login" component={LoginPage} />
        <PrivateRoute path="/" exact component={HomePage} />
        <PrivateRoute path="/users" component={UserPage} />
        {/* Adicione outras rotas conforme necessário */}
      </Switch>
    </Router>
  );
}

export default App;