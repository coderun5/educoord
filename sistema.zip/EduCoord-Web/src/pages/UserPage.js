import React, { useState, useEffect } from 'react';
import axios from 'axios';
import config from '../config';
import { Table, Button, Form, Modal } from 'react-bootstrap';

const UserPage = () => {
  const [users, setUsers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [editingUser, setEditingUser] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const response = await axios.get(`${config.apiUrl}/users`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    setUsers(response.data);
  };

  const handleCreateOrUpdateUser = async (e) => {
    e.preventDefault();
    if (editingUser) {
      await axios.put(`${config.apiUrl}/users/${editingUser._id}`, { name, email, role }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
    } else {
      await axios.post(`${config.apiUrl}/users`, { name, email, password, role }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
    }
    fetchUsers();
    setShowModal(false);
    setName('');
    setEmail('');
    setPassword('');
    setRole('');
    setEditingUser(null);
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setName(user.name);
    setEmail(user.email);
    setRole(user.role);
    setShowModal(true);
  };

  const handleDeleteUser = async (userId) => {
    await axios.delete(`${config.apiUrl}/users/${userId}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    fetchUsers();
  };

  return (
    <div>
      <h1>Usuários</h1>
      <Button onClick={() => setShowModal(true)}>Adicionar Usuário</Button>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Nome</th>
            <th>Email</th>
            <th>Papel</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user._id}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.role}</td>
              <td>
                <Button variant="warning" onClick={() => handleEditUser(user)}>Editar</Button>
                <Button variant="danger" onClick={() => handleDeleteUser(user._id)}>Excluir</Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      <Modal show={showModal} onHide={() => setShowModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>{editingUser ? 'Editar Usuário' : 'Adicionar Usuário'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleCreateOrUpdateUser}>
            <Form.Group>
              <Form.Label>Nome</Form.Label>
              <Form.Control type="text" value={name} onChange={(e) => setName(e.target.value)} required />
            </Form.Group>
            <Form.Group>
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </Form.Group>
            {!editingUser && (
              <Form.Group>
                <Form.Label>Senha</Form.Label>
                <Form.Control type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </Form.Group>
            )}
            <Form.Group>
              <Form.Label>Papel</Form.Label>
              <Form.Control as="select" value={role} onChange={(e) => setRole(e.target.value)} required>
                <option value="">Selecione o papel</option>
                <option value="admin">Admin</option>
                <option value="teacher">Professor</option>
                <option value="student">Aluno</option>
                <option value="parent">Responsável</option>
              </Form.Control>
            </Form.Group>
            <Button type="submit">{editingUser ? 'Atualizar' : 'Criar'}</Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default UserPage;