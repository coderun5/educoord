import React, { useState, useEffect } from 'react';
import axios from 'axios';
import config from '../config';
import { Line } from 'react-chartjs-2';
import { Table } from 'react-bootstrap';

const DashboardPage = () => {
  const [performanceData, setPerformanceData] = useState([]);
  const [attendanceData, setAttendanceData] = useState([]);

  useEffect(() => {
    fetchPerformanceData();
    fetchAttendanceData();
  }, []);

  const fetchPerformanceData = async () => {
    const response = await axios.get(`${config.apiUrl}/performance`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    setPerformanceData(response.data);
  };

  const fetchAttendanceData = async () => {
    const response = await axios.get(`${config.apiUrl}/attendance`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    setAttendanceData(response.data);
  };

  const performanceChartData = {
    labels: performanceData.map(data => data.date),
    datasets: [
      {
        label: 'Desempenho Acadêmico',
        data: performanceData.map(data => data.score),
        borderColor: 'rgba(75,192,192,1)',
        fill: false,
      },
    ],
  };

  return (
    <div>
      <h1>Dashboard</h1>
      <h2>Desempenho Acadêmico</h2>
      <Line data={performanceChartData} />
      <h2>Frequência</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Data</th>
            <th>Aluno</th>
            <th>Presença</th>
          </tr>
        </thead>
        <tbody>
          {attendanceData.map(record => (
            <tr key={record.id}>
              <td>{record.date}</td>
              <td>{record.studentName}</td>
              <td>{record.present ? 'Presente' : 'Ausente'}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default DashboardPage;