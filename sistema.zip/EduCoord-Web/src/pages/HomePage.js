import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Bem-vindo ao EduCoord</h1>
    </div>
  );
};

export default HomePage;