# EduCoord - Interface Web

## Visão Geral
Esta é a interface web do sistema de gestão escolar EduCoord, desenvolvida com React.

## Scripts Disponíveis

### `npm start`
Inicia o servidor de desenvolvimento.

### `npm build`
Gera os arquivos de produção.

## Estrutura de Pastas
```
EduCoord-Web/
  ├── public/
  ├── src/
  │   ├── components/
  │   ├── pages/
  │   ├── App.js
  │   ├── index.js
  ├── package.json
```